const express = require('express');
const admin = require('firebase-admin');
const path = require('path');
require('dotenv').config();

const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API to get the secret key
app.get('/api/secret-key', (req, res) => {
  res.json({ secretKey: process.env.SECRET_KEY });
});

// CREATE: Store encrypted user data with IV
app.post('/api/users', async (req, res) => {
  try {
    const { encryptedData, iv } = req.body;
    if (!encryptedData || !iv) {
      return res.status(400).send('Missing encrypted data or IV');
    }
    const docRef = await db.collection('users').add({
      encryptedData,
      iv,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    res.status(201).json({ id: docRef.id });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// READ: Get all users
app.get('/api/users', async (req, res) => {
  try {
    const snapshot = await db.collection('users').orderBy('createdAt', 'desc').get();
    const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.status(200).json(users);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// NEW: Get the most recent user
app.get('/api/users/latest', async (req, res) => {
  try {
    const snapshot = await db.collection('users')
      .orderBy('createdAt', 'desc')
      .limit(1)
      .get();
    if (snapshot.empty) {
      return res.status(404).send('No users found');
    }
    const user = snapshot.docs[0].data();
    user.id = snapshot.docs[0].id;
    res.status(200).json(user);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// UPDATE and DELETE (unchanged)
app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;
    if (!Object.keys(data).length) {
      return res.status(400).send('No data provided to update');
    }
    await db.collection('users').doc(id).update({
      ...data,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    res.status(200).send('User updated');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.delete('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await db.collection('users').doc(id).delete();
    res.status(200).send('User deleted');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});