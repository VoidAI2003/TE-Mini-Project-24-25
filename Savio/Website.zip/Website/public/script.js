let secretKey;

// Fetch the secret key on page load
async function fetchSecretKey() {
  try {
    const response = await fetch('/api/secret-key');
    if (!response.ok) throw new Error('Failed to fetch secret key');
    const data = await response.json();
    secretKey = data.secretKey;
  } catch (error) {
    console.error(error);
    alert('Error fetching secret key. Please refresh the page.');
  }
}

// Helper functions
function stringToArrayBuffer(str) {
  return new TextEncoder().encode(str);
}

function arrayBufferToHex(buffer) {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToArrayBuffer(hex) {
  return new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
}

function generateIV() {
  return crypto.getRandomValues(new Uint8Array(16)); // 16 bytes for AES-CBC
}

async function encryptData(data, key, iv) {
  const keyBuffer = stringToArrayBuffer(key);
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyBuffer,
    { name: 'AES-CBC' },
    false,
    ['encrypt']
  );
  const dataBuffer = stringToArrayBuffer(JSON.stringify(data));
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-CBC', iv },
    cryptoKey,
    dataBuffer
  );
  return arrayBufferToHex(encrypted);
}

async function decryptData(encryptedHex, key, ivHex) {
  try {
    const keyBuffer = stringToArrayBuffer(key);
    const iv = hexToArrayBuffer(ivHex);
    const encryptedBuffer = hexToArrayBuffer(encryptedHex);
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyBuffer,
      { name: 'AES-CBC' },
      false,
      ['decrypt']
    );
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-CBC', iv },
      cryptoKey,
      encryptedBuffer
    );
    return JSON.parse(new TextDecoder().decode(decrypted));
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
}

// Form submission with encryption
document.getElementById('userForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!secretKey) {
    alert('Secret key not loaded yet. Please wait.');
    return;
  }

  const name = document.getElementById('name').value;
  const age = document.getElementById('age').value;
  const address = document.getElementById('address').value;
  const data = { name, age, address };

  try {
    const iv = generateIV();
    const encryptedData = await encryptData(data, secretKey, iv);
    const ivHex = arrayBufferToHex(iv);

    const response = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ encryptedData, iv: ivHex }),
    });
    if (!response.ok) throw new Error('Failed to add user');
    alert('User added successfully!');
    document.getElementById('userForm').reset();
    fetchUsers();
  } catch (error) {
    alert(error.message);
  }
});

// Fetch and display all users
async function fetchUsers() {
  try {
    const response = await fetch('/api/users');
    if (!response.ok) throw new Error('Failed to fetch users');
    const users = await response.json();
    const userDiv = document.getElementById('users');
    let userHTML = '<h2>Users:</h2>';
    for (const user of users) {
      const decryptedData = await decryptData(user.encryptedData, secretKey, user.iv);
      userHTML += `<p>${decryptedData.name}, ${decryptedData.age}, ${decryptedData.address} 
        <button onclick="deleteUser('${user.id}')">Delete</button>
        <button onclick="updateUser('${user.id}')">Update</button></p>`;
    }
    userDiv.innerHTML = userHTML;
  } catch (error) {
    console.error(error);
    document.getElementById('users').innerHTML = '<p>Error loading users</p>';
  }
}

// Fetch and display the latest submission
document.getElementById('fetchLatest').addEventListener('click', async () => {
  if (!secretKey) {
    alert('Secret key not loaded yet. Please wait.');
    return;
  }

  try {
    const response = await fetch('/api/users/latest');
    if (!response.ok) throw new Error('Failed to fetch latest user');
    const user = await response.json();
    const decryptedData = await decryptData(user.encryptedData, secretKey, user.iv);
    document.getElementById('latestUser').innerHTML = `
      <h2>Latest Submission:</h2>
      <p>Name: ${decryptedData.name}, Age: ${decryptedData.age}, Address: ${decryptedData.address}</p>
    `;
  } catch (error) {
    document.getElementById('latestUser').innerHTML = `<p>Error: ${error.message}</p>`;
  }
});

async function deleteUser(id) {
  try {
    const response = await fetch(`/api/users/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Failed to delete user');
    fetchUsers();
  } catch (error) {
    alert(error.message);
  }
}

async function updateUser(id) {
  alert('Update not implemented for encrypted data yet.');
}

fetchSecretKey();
fetchUsers();